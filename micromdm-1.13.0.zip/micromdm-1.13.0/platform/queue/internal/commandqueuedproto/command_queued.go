package commandqueued

//go:generate protoc --go_out=. --go_opt=paths=source_relative command_queued.proto
