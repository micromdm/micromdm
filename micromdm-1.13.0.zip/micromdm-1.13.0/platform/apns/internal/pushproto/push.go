package pushproto

//go:generate protoc --go_out=. --go_opt=paths=source_relative push.proto
