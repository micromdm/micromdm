package devicecommandproto

//go:generate protoc --go_out=. --go_opt=paths=source_relative device_command.proto
