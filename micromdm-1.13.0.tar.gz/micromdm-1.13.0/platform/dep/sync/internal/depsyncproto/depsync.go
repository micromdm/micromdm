package depsyncproto

//go:generate protoc --go_out=. --go_opt=paths=source_relative depsync.proto
