package blueprintproto

//go:generate protoc --go_out=. --go_opt=paths=source_relative blueprint.proto
